package eLib;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import eLib.komponenMakeOver.buttonMakeOver;

@SuppressWarnings("serial")
public class popup extends JDialog implements ActionListener{
	JPanel nord, centre, sud, panbout, pan, panMsj;
	JLabel icon, msj;
	JPasswordField text;
	buttonMakeOver val;
	JLabel info;
	
	private static connection con;
	private static Statement stat;
	private static ResultSet rese;
	private static ResultSet rese2;

	static String req;
	static String req2;
	String state = "Active";
	
	public popup(String Tags){
		setUndecorated(true);
		setVisible(true);		
		setSize(300, 130);
		setLocationRelativeTo(null);
		setShape(new RoundRectangle2D.Double(1, 1, 300, 130, 15, 15));
		
		msj = new JLabel("");
		if(Left_Panel.tags.equals("Catalogue")){
			msj.setText("<html><b>"+Left_Panel.tags+"</b></html>");
		}
		if(Left_Panel.tags.equals("Emprunter livre")){
			msj.setText("<html><b>"+Left_Panel.tags+"</b></html>");
		}
		if(Left_Panel.tags.equals("Service client")){
			msj.setText("<html><b>"+Left_Panel.tags+"</b></html>");
		}
		
		panMsj = new JPanel();
		panMsj.setOpaque(false);
		panMsj.add(msj);
		
		icon = new JLabel(new ImageIcon(getClass().getResource("min.png")));
        icon.setToolTipText("Fermer");
		icon.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				dispose();
			}
		});		
		panbout = new JPanel();
		panbout.setOpaque(false);
		panbout.setLayout(new FlowLayout());
		panbout.add(icon);
		
		nord = new JPanel();
		nord.setLayout(new BorderLayout());
		nord.setPreferredSize(new Dimension(300, 30));
		nord.setBackground(Color.decode("#afafaf"));
		nord.add(panbout, BorderLayout.EAST);
		nord.add(panMsj, BorderLayout.CENTER);
		
		text = new JPasswordField("Entrez votre code PIN");
		info=new JLabel("Entrez votre code PIN");
		text.setForeground(Color.GRAY);
		text.setFocusable(false);
		text.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				text.setFocusable(true);
			}
		});	
		text.addFocusListener(new FocusListener() {
	        @Override
	        public void focusGained(FocusEvent e) {
	            if (text.getText().equals("Entrez votre code PIN")) {
	            	text.setText("");
	            	text.setForeground(Color.BLACK);
	            }
	        }
	        @Override
	        public void focusLost(FocusEvent e) {
	            if (text.getText().isEmpty()) {
	            	text.setForeground(Color.GRAY);
	            	text.setText("Entrez votre code PIN");
	            }
	        }
	    });
		
		val = new eLib.komponenMakeOver.buttonMakeOver();
		val.setPreferredSize(new Dimension(100, 40));
		val.setForeground(Color.GRAY);
		val.setText("Valider");
		val.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
		val.addActionListener(this);
		val.setBounds(-10, 0, 420, 80);
		
		pan = new JPanel();
		pan.setOpaque(false);
		pan.setLayout(new BorderLayout());
		pan.setPreferredSize(new Dimension(250, 40));
		pan.add(text, BorderLayout.SOUTH);
		pan.add(info,BorderLayout.NORTH);
		
		centre = new JPanel();
		centre.setBackground(Color.decode("#ececec"));
		centre.setPreferredSize(new Dimension(300, 105));
		centre.add(pan);
		
		sud = new JPanel();
		sud.setBackground(Color.decode("#ececec"));
		sud.setPreferredSize(new Dimension(300, 40));
		sud.add(val);
		
		add(nord, BorderLayout.NORTH);
		add(centre, BorderLayout.CENTER);
		add(sud, BorderLayout.SOUTH);
		
		validate();
	}
	
	public void Rehabilite(){
		if(text.getText().equals("") || text.getText().equals("Entrez votre code PIN")){
			
		}else{
			try {
				con = new connection();
			    stat = con.getStatement();
			    req = "select etat,id_abonne from carte where code_PIN = '"+text.getText()+"'";
			    rese = stat.executeQuery(req);
			    
				SimpleDateFormat sdf;
				
				String aujour;
				
				sdf = new SimpleDateFormat("dd/MM/yyyy");
				aujour = sdf.format(new Date());
			    String id_abonne = null;
			    
			    if(rese.next()){
			    	if(rese.getString("etat").equals("Active")){
			    		msj.setText("<html><b>Votre carte n'a pas �t� suspendue !</b></html>");
						text.setText("");
						
			    	}else{
			    		id_abonne=rese.getString("id_abonne");
			    		req = "Update abonne SET dateEnr = '"+aujour+"' where id_abonne = '"+id_abonne+"'";
			    		req2 = "Update carte SET etat = '"+state+"' where code_PIN = '"+text.getText()+"'";
			    	
						stat.executeUpdate(req);
						stat.executeUpdate(req2);
						msj.setText("<html><b>Votre carte a �t� r�habilite !</b></html>");
						text.setText("");
			    	}
			    }
			} catch (SQLException e) {
				JOptionPane.showMessageDialog(null, e.getMessage());
			}
		}
	}
	
	public void acces(){
		if(text.getText().equals("") || text.getText().equals("Entrez votre code PIN")){
			
		}else{
			try {
				con = new connection();
				stat = con.getStatement();
				req = "SELECT * FROM carte WHERE code_PIN = "+text.getText()+" and id_abonne = "+login.id;			
				rese = stat.executeQuery(req);
				if(rese.next()){
					if(rese.getString("etat").equals("Active")){
						if(Left_Panel.tags.equals("Catalogue")){
							msj.setText("<html><b>"+Left_Panel.tags+"</b></html>");
							call_Catalogue_Pan();
							dispose();
						}
						if(Left_Panel.tags.equals("Emprunter livre")){
							msj.setText("<html><b>"+Left_Panel.tags+"</b></html>");
			            	call_Emprunt_Pan();
			            	dispose();
						}
					}else{
						msj.setText("<html><b>Votre carte a �t� suspendue !</b></html>");
						text.setText("");
					}					
				}else{
					msj.setText("<html><b>Code incorrect, r�essayez!</b></html>");
					text.setText("");
				}
			} catch (SQLException e) {
				JOptionPane.showMessageDialog(null, e.getMessage());
				e.printStackTrace();
			}
		}		
	}
	
	public void call_Catalogue_Pan(){
		Lanceur.panCenter.removeAll();
		Lanceur.panCenter.setVisible(false);
		Lanceur.panCenter.add(new Catalogue_Panel());
		Lanceur.panCenter.setVisible(true);
		setVisible(true);
	}
	
	public void call_Emprunt_Pan(){
		Lanceur.panCenter.removeAll();
		Lanceur.panCenter.setVisible(false);
		Lanceur.panCenter.add(new Emprunt_Panel());
		Lanceur.panCenter.setVisible(true);
		setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==val){
			if(Left_Panel.tags.equals("Service client")){
				Rehabilite();
			}else{
				acces();
			}
			
		}
	}
}
