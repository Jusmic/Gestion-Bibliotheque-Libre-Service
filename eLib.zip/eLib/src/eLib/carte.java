package eLib;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class carte {
int cd_PIN, id_abonne;
String period, validite;

private static connection con;
private static Statement stat;
private static ResultSet rese;

static String req;
	
	public carte(int cd_PIN, int id_abonne, String period, String validite){
		this.cd_PIN = cd_PIN;
		this.id_abonne = id_abonne;
		this.period = period;
		this.validite = validite;
	}
	
	//Accesseurs....
	public int getCd_PIN(){
		return this.cd_PIN;
	}
	public int getId_abonne(){
		return this.id_abonne;
	}
	public String getPeriod(){
		return this.period;
	}
	public String getValidite(){
		return this.validite;
	}
	
	//Mutateurs...
	public void setCd_PIN(int cd_PIN){
		this.cd_PIN = cd_PIN;
	}
	public void setId_abonne(int id_abonne){
		this.id_abonne = id_abonne;
	}
	public void setPeriod(String period){
		this.period = period;
	}
	public void setValidite(String validite){
		this.validite = validite;
	}
	
	public static void ins_Carte(int cd_PIN, int id_abonne, String period, String validite){
		try {
			con = new connection();
			stat = con.getStatement();
			req = "SELECT * FROM carte WHERE code_PIN = "+cd_PIN;			
			rese = stat.executeQuery(req);
			if(rese.next()){
				JOptionPane.showMessageDialog(null, "Ce code �xiste d�j� dans notre archive.");
			}else{
				req = "INSERT INTO carte VALUES("+cd_PIN+", "+id_abonne+", '"+period+"', '"+validite+"')";
				stat.executeUpdate(req);
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
			e.printStackTrace();
		}
	}
}
