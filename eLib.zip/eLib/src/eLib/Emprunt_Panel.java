package eLib;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import eLib.komponenMakeOver.buttonMakeOver;

@SuppressWarnings("serial")
public class Emprunt_Panel extends JPanel implements ActionListener{
JPanel main, panData, panButton;
JLabel lbCodeEmprnt, lbISBN, lbTitre, lbCode_PIN, lbDate;
JTextField txCodeEmprnt, txTitre, txDate;
 JPasswordField txCode_PIN;
@SuppressWarnings("rawtypes")
JComboBox cbISBN;
TitledBorder bord;
SimpleDateFormat sdf;
buttonMakeOver btn, btn1;

private connection con;
private Statement stat;
private ResultSet rese;

static String req, code;
String disp = "Non", disp1 = "Oui";

int cpt, i = 1;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Emprunt_Panel(){
		bord = new TitledBorder("<html><br><b>Emprunter livre</b></html>");
		
		lbCodeEmprnt = new JLabel("Code Emprunt :");
		txCodeEmprnt = new JTextField();
		generate();
		
		lbISBN = new JLabel("ISBN :");
		cbISBN = new JComboBox();
		cbISBN.addItem("Selectionnez code livre");		
		cbISBN.addActionListener(this);
		addISBN();
		
		lbTitre = new JLabel("Titre :");
		txTitre = new JTextField();
		txTitre.setEditable(false);
		
		lbCode_PIN = new JLabel("Code PIN :");
		txCode_PIN = new JPasswordField();
		txCode_PIN.setFocusable(false);
		addCode_PIN();
		
		sdf = new SimpleDateFormat("dd/MM/yyyy");
		
		lbDate = new JLabel("Date emprunt :");
		txDate = new JTextField();
		txDate.setText(sdf.format(new Date()));
		txDate.setEditable(false);	
		
		panData = new JPanel();
		panData.setPreferredSize(new Dimension(570,370));
		panData.setBorder(bord);
		panData.setOpaque(false);
		panData.setLayout(new GridLayout(10, 1));
		panData.add(lbCodeEmprnt);
		panData.add(txCodeEmprnt);
		panData.add(lbISBN);
		panData.add(cbISBN);
		panData.add(lbTitre);
		panData.add(txTitre);
		panData.add(lbCode_PIN);
		panData.add(txCode_PIN);
		panData.add(lbDate);
		panData.add(txDate);
		
		
		btn = new eLib.komponenMakeOver.buttonMakeOver();
		btn.setPreferredSize(new Dimension(180, 40));
		btn.setForeground(new java.awt.Color(0, 0, 0));
		btn.setText("Annuler");
		btn.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
		btn.addActionListener(this);
		btn.setBounds(-10, 0, 420, 80);
		
		btn1 = new eLib.komponenMakeOver.buttonMakeOver();
		btn1.setPreferredSize(new Dimension(180, 40));
		btn1.setForeground(Color.decode("#3193fe"));
		btn1.setText("Sauvegarder");
		btn1.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
		btn1.addActionListener(this);
		btn1.setBounds(-10, 0, 420, 80);
		
		panButton = new JPanel();
		panButton.setPreferredSize(new Dimension(580,40));
		panButton.add(btn);
		panButton.add(btn1);
		
		
		main = this;
		main.setLayout(new BorderLayout());
		main.setPreferredSize(new Dimension(580,460));
		main.setBackground(Color.decode("#ececec"));
		main.add(panData, BorderLayout.NORTH);
		main.add(panButton, BorderLayout.CENTER);
	}
	
	public void generate(){
		try {
			con = new connection();
		    stat = con.getStatement();
		    req = "SELECT compteur FROM abonne where id_abonne = "+login.id;
			rese = stat.executeQuery(req);
			if(rese.next()){
				cpt = Integer.parseInt(rese.getString("compteur"));
				code = login.username.substring(0, 3)+"-"+(cpt+i);
				txCodeEmprnt.setText(code);
				txCodeEmprnt.setEditable(false);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void updateCompteur(){
		try {
			con = new connection();
		    stat = con.getStatement();
			req = "Update abonne SET compteur = "+(cpt+i)+" where id_abonne ="+login.id;
			stat.executeUpdate(req);
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
	}
	
	
	@SuppressWarnings("unchecked")
	public void addISBN(){
		try {
			con = new connection();
			stat = con.getStatement();
			req = "select ISBN from livre where disponibilite ='"+disp1+"'";
			rese = stat.executeQuery(req);
			while(rese.next()){
				cbISBN.addItem(rese.getString("ISBN"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	public void addCode_PIN(){
		try {
			con = new connection();
			stat = con.getStatement();
			req = "select code_PIN from carte where id_abonne ="+login.id;
			rese = stat.executeQuery(req);
			while(rese.next()){
				txCode_PIN.setText(rese.getString("code_PIN"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void addTitre(){
		if(cbISBN.getSelectedItem().equals("Selectionnez code livre")){
			txTitre.setText("");
		}else{
			try {
				con = new connection();
				stat = con.getStatement();
				req = "select titre from livre where ISBN ='"+cbISBN.getSelectedItem().toString()+"'";
				rese = stat.executeQuery(req);
				if(rese.next()){
					txTitre.setText(rese.getString("titre"));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
	}
	
	public void clean(){
		txCodeEmprnt.setText("");
		cbISBN.setSelectedItem("Selectionnez code livre");
		txTitre.setText("");
	}
	
	public void updateDispo(){
		try {
			con = new connection();
		    stat = con.getStatement();
			req = "Update livre SET disponibilite = '"+disp+"' where ISBN ='"+cbISBN.getSelectedItem().toString()+"'";
			stat.executeUpdate(req);
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
	}
	
	public void inserer(){
		if(txCodeEmprnt.getText().equals("") || cbISBN.getSelectedItem().equals("Selectionnez code livre") || txCode_PIN.getText().equals("Selectionnez code PIN")){
			JOptionPane.showMessageDialog(null, "Tous les champs sont obligatoires.");
		}else{
			Emprunt.ins_Emprnt(txCodeEmprnt.getText(), Integer.parseInt(txCode_PIN.getText()), cbISBN.getSelectedItem().toString(), txDate.getText());
			JOptionPane.showMessageDialog(null, "Enregistrement reussi!!!");
			updateCompteur();
			updateDispo();
			clean();
			call_Emprunt_Pan();
		}
	}
	
	
	public void verifCompteur(){
		try {
			con = new connection();
		    stat = con.getStatement();
		    req = "SELECT compteur FROM abonne where id_abonne ="+login.id;
			rese = stat.executeQuery(req);
			if(rese.next()){
				if(rese.getInt("compteur") <= 2){
					inserer();
				}else{
					JOptionPane.showMessageDialog(null, "Vous ne pouvez pas emprunter plus de 3 livres.");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public void call_Emprunt_Pan(){
		Lanceur.panCenter.removeAll();
		Lanceur.panCenter.setVisible(false);
		Lanceur.panCenter.add(new Emprunt_Panel());
		Lanceur.panCenter.setVisible(true);
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e){
		if(e.getSource() == btn){
			clean();
		}
		
		if(e.getSource() == btn1){
			verifCompteur();
		}
		
		if(e.getSource() == cbISBN){
			addTitre();
		}
	}
}
