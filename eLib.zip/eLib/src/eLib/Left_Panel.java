package eLib;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import eLib.komponenMakeOver.buttonMakeOver;

@SuppressWarnings("serial")
public class Left_Panel extends JPanel{
JPanel main, panButton, space, space1, space2;
JLabel image;
buttonMakeOver btMakeOver, btMakeOver1, btMakeOver2, btMakeOver3;
static String tags ="";

	public Left_Panel(){		
		btMakeOver = new eLib.komponenMakeOver.buttonMakeOver();
		btMakeOver.setPreferredSize(new Dimension(180, 40));
		btMakeOver.setForeground(new java.awt.Color(255, 255, 255));
		btMakeOver.setText("Emprunter livre");
		btMakeOver.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
		btMakeOver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	tags = "Emprunter livre";
            	new popup(tags);
            }
        });
		btMakeOver.setBounds(-10, 0, 420, 80);
		
		btMakeOver1 = new eLib.komponenMakeOver.buttonMakeOver();
		btMakeOver1.setPreferredSize(new Dimension(180, 40));
		btMakeOver1.setForeground(new java.awt.Color(255, 255, 255));
		btMakeOver1.setText("Catalogue");
		btMakeOver1.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
		btMakeOver1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	tags = "Catalogue";
            	new popup(tags);
            }
        });
		btMakeOver1.setBounds(-10, 0, 420, 80);
		
		btMakeOver2 = new eLib.komponenMakeOver.buttonMakeOver();
		btMakeOver2.setPreferredSize(new Dimension(180, 40));
		btMakeOver2.setForeground(new java.awt.Color(255, 255, 255));
		btMakeOver2.setText("Enrg. Ouvrage");
		btMakeOver2.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
		btMakeOver2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	call_Ouvrage_Pan();
            }
        });
		btMakeOver2.setBounds(-10, 0, 420, 80);
		
		if(login.Tip.equals("User")){
			btMakeOver2.setEnabled(false);
			btMakeOver2.setForeground(Color.LIGHT_GRAY);
		}
		
		btMakeOver3 = new eLib.komponenMakeOver.buttonMakeOver();
		btMakeOver3.setPreferredSize(new Dimension(180, 40));
		btMakeOver3.setForeground(new java.awt.Color(255, 255, 255));
		btMakeOver3.setText("Service client");
		btMakeOver3.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
		btMakeOver3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	tags = "Service client";
            	new popup(tags);
            }
        });
		btMakeOver3.setBounds(-10, 0, 420, 80);
		
		if(login.Tip.equals("User")){
			btMakeOver3.setEnabled(false);
			btMakeOver3.setForeground(Color.LIGHT_GRAY);
		}
		
		space = new JPanel();
		space.setOpaque(false);
		space.setPreferredSize(new Dimension(200,7));
		
		space1 = new JPanel();
		space1.setOpaque(false);
		space1.setPreferredSize(new Dimension(200,7));
		
		space2 = new JPanel();
		space2.setOpaque(false);
		space2.setPreferredSize(new Dimension(200,7));
		
		image = new JLabel(new ImageIcon(getClass().getResource("account_circle.png")));
		image.setText("<html><b>Salut, "+login.username+"!</b></html>");
		image.setForeground(Color.white);
		
		panButton = new JPanel();		
		panButton.setOpaque(false);
		panButton.setPreferredSize(new Dimension(200, 270));
		panButton.add(image);
		panButton.add(btMakeOver);
		panButton.add(space);
		panButton.add(btMakeOver1);
		panButton.add(space1);
		panButton.add(btMakeOver2);
		panButton.add(space2);
		panButton.add(btMakeOver3);
		main = this;
		main.setBackground(Color.decode("#556768"));		
		main.setPreferredSize(new Dimension(210,460));
		main.add(panButton);
	}
	
	public void call_Ouvrage_Pan(){
		Lanceur.panCenter.removeAll();
		Lanceur.panCenter.setVisible(false);
		Lanceur.panCenter.add(new Livre_Panel());
		Lanceur.panCenter.setVisible(true);
		setVisible(true);
	}
}
