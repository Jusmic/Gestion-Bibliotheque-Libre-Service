package eLib;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import eLib.komponenMakeOver.buttonMakeOver;

@SuppressWarnings("serial")
public class box extends JDialog implements ActionListener{
	JPanel nord, centre, sud, panbout, pan, panMsj;
	JLabel icon, msj;
	JTextField text;
	buttonMakeOver val;
	
	private static connection con;
	private static Statement stat;
	private static ResultSet rese;

	static String req;
	String disp = "Oui", codeLivre = "";
	int i = 1, cmpteur;
	
	public box(String Tags){
		setUndecorated(true);
		setVisible(true);		
		setSize(300, 105);
		setLocationRelativeTo(null);
		setShape(new RoundRectangle2D.Double(1, 1, 300, 105, 15, 15));
		
		msj = new JLabel("<html><b>Boite � livre</b></html>");
		panMsj = new JPanel();
		panMsj.setOpaque(false);
		panMsj.add(msj);
		
		icon = new JLabel(new ImageIcon(getClass().getResource("min.png")));
        icon.setToolTipText("Fermer");
		icon.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				dispose();
				new Principale(null);
			}
		});		
		panbout = new JPanel();
		panbout.setOpaque(false);
		panbout.setLayout(new FlowLayout());
		panbout.add(icon);
		
		nord = new JPanel();
		nord.setLayout(new BorderLayout());
		nord.setPreferredSize(new Dimension(300, 30));
		nord.setBackground(Color.decode("#afafaf"));
		nord.add(panbout, BorderLayout.EAST);
		nord.add(panMsj, BorderLayout.CENTER);
		
		text = new JTextField("Entrez l'ISBN du livre");
		text.setForeground(Color.GRAY);
		text.setFocusable(false);
		text.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				text.setFocusable(true);
			}
		});	
		text.addFocusListener(new FocusListener() {
	        @Override
	        public void focusGained(FocusEvent e) {
	            if (text.getText().equals("Entrez l'ISBN du livre")) {
	            	text.setText("");
	            	text.setForeground(Color.BLACK);
	            }
	        }
	        @Override
	        public void focusLost(FocusEvent e) {
	            if (text.getText().isEmpty()) {
	            	text.setForeground(Color.GRAY);
	            	text.setText("Entrez l'ISBN du livre");
	            }
	        }
	    });
		
		val = new eLib.komponenMakeOver.buttonMakeOver();
		val.setPreferredSize(new Dimension(100, 40));
		val.setForeground(Color.GRAY);
		val.setText("Valider");
		val.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
		val.addActionListener(this);
		val.setBounds(-10, 0, 420, 80);
		
		pan = new JPanel();
		pan.setOpaque(false);
		pan.setLayout(new BorderLayout());
		pan.setPreferredSize(new Dimension(250, 40));
		pan.add(text, BorderLayout.NORTH);
		
		centre = new JPanel();
		centre.setBackground(Color.decode("#ececec"));
		centre.setPreferredSize(new Dimension(300, 105));
		centre.add(pan);
		
		sud = new JPanel();
		sud.setBackground(Color.decode("#ececec"));
		sud.setPreferredSize(new Dimension(300, 40));
		sud.add(val);
		
		add(nord, BorderLayout.NORTH);
		add(centre, BorderLayout.CENTER);
		add(sud, BorderLayout.SOUTH);
		
		validate();
	}
	
	public void Downgrade(int code){
		try {
			con = new connection();
			stat = con.getStatement();
			req = "SELECT compteur FROM abonne WHERE id_abonne = "+code;			
			rese = stat.executeQuery(req);
			if(rese.next()){
				cmpteur = rese.getInt("compteur");
				if(cmpteur == 0){
					
				}else{
					req ="update abonne set compteur = "+(cmpteur-i)+" where id_abonne = "+code;
					stat.executeUpdate(req);
				}				
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
			e.printStackTrace();
		}
	}
	
	public void getID(int code){
		try {
			con = new connection();
			stat = con.getStatement();
			req = "select abonne.id_abonne, carte.code_PIN from abonne inner join carte on carte.id_abonne = abonne.id_abonne where code_PIN ="+code;			
			rese = stat.executeQuery(req);
			if(rese.next()){
				Downgrade(rese.getInt("id_abonne"));
			}else{
				msj.setText("<html><b>Code incorrect, r�essayez!</b></html>");
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
			e.printStackTrace();
		}
	}
	
	public void delete(String code){
		try {
			con = new connection();
			stat = con.getStatement();
			req = "delete from emprunt where ISBN = '"+code+"'";			
			stat.executeUpdate(req);
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
			e.printStackTrace();
		}
	}
	
	public void updateDispo(String code){
		try {
			con = new connection();
		    stat = con.getStatement();
			req = "Update livre SET disponibilite = '"+disp+"' where ISBN ='"+code+"'";
			stat.executeUpdate(req);
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
	}
	
	public void acces(){
		if(text.getText().equals("") || text.getText().equals("Entrez l'ISBN du livre")){
			
		}else{
			try {
				con = new connection();
				stat = con.getStatement();
				req = "select code_PIN, ISBN from emprunt where ISBN = '"+text.getText()+"'";			
				rese = stat.executeQuery(req);
				if(rese.next()){
					codeLivre = rese.getString("ISBN");
					getID(rese.getInt("code_PIN"));
					updateDispo(codeLivre);
					delete(codeLivre);
					msj.setText("<html><b>Livre replace avec succes!</b></html>");
					text.setText("");
				}else{
					msj.setText("<html><b>Aucun emprunt trouve pour ce live!</b></html>");
				}
			} catch (SQLException e) {
				JOptionPane.showMessageDialog(null, e.getMessage());
				e.printStackTrace();
			}
		}		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==val){
			acces();
		}
	}
}
