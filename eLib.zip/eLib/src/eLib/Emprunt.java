package eLib;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class Emprunt {
private String codeEmprnt, isbn, dateEmprnt;
int code_PIN;

private static connection con;
private static Statement stat;
private static ResultSet rese;

static String req;

	public Emprunt(String codeEmprnt, int code_PIN, String isbn, String dateEmprnt){
		this.codeEmprnt = codeEmprnt;
		this.code_PIN = code_PIN;
		this.isbn = isbn;
		this.dateEmprnt = dateEmprnt;
	}
	
	//Accesseurs...
	public String getCodeEmprunt(){
		return codeEmprnt;
	}
	public int getCode_PIN(){
		return code_PIN;
	}
	public String getIsbn(){
		return isbn;
	}
	public String getDateEmprnt(){
		return dateEmprnt;
	}
	
	//Mutateurs...
	public void setCodeEmprunt(String codeEmprnt){
		this.codeEmprnt = codeEmprnt;
	}
	public void setCode_PIN(int code_PIN){
		this.code_PIN = code_PIN;
	}
	public void setIsbn(String isbn){
		this.isbn = isbn;
	}
	public void setDateEmprnt(String dateEmprnt){
		this.dateEmprnt = dateEmprnt;
	}
	
	public static void ins_Emprnt(String codeEmprnt, int code_PIN, String isbn, String dateEmprnt){
		try {
			int size =0;
			con = new connection();
			stat = con.getStatement();
			req = "SELECT * FROM emprunt WHERE Code_emprunt = '"+codeEmprnt+"'";			
			rese = stat.executeQuery(req);
			
			rese.last();
			size=rese.getRow();
			rese.isBeforeFirst();
			System.out.println("NUMBER "+size);
			
			if(rese.next() ){
				JOptionPane.showMessageDialog(null, "Ce code �xiste d�j� dans notre archive.");
			}else{
				req = "INSERT INTO emprunt VALUES('"+codeEmprnt+"', "+code_PIN+", '"+isbn+"', '"+dateEmprnt+"')";
				stat.executeUpdate(req);
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
			e.printStackTrace();
		}
	}
}
