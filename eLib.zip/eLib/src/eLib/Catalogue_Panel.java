package eLib;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import eLib.komponenMakeOver.buttonMakeOver;

@SuppressWarnings("serial")
public class Catalogue_Panel extends JPanel implements ActionListener{
JPanel main, panSearch;
JTextField searchText;
TitledBorder bord;
buttonMakeOver btn;

JTable t;
String titreT[];
Object ob[][];
JScrollPane scrol;

private connection con;
private Statement stat;
private ResultSet rese;
String req;

	public Catalogue_Panel(){
		searchText = new JTextField("Tapez le nom du livre");
		searchText.setForeground(Color.GRAY);
	    searchText.addFocusListener(new FocusListener() {
	        @Override
	        public void focusGained(FocusEvent e) {
	            if (searchText.getText().equals("Tapez le nom du livre")) {
	                searchText.setText("");
	                searchText.setForeground(Color.BLACK);
	            }
	        }
	        @Override
	        public void focusLost(FocusEvent e) {
	            if (searchText.getText().isEmpty()) {
	                searchText.setForeground(Color.GRAY);
	                searchText.setText("Tapez le nom du livre");
	            }
	        }
	    });
		
		btn = new eLib.komponenMakeOver.buttonMakeOver();
		btn.setForeground(new java.awt.Color(0, 0, 0));
		btn.setText("Rechercher");
		btn.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
		btn.addActionListener(this);
		btn.setBounds(-10, 0, 420, 80);
		
		bord = new TitledBorder("<html><br><b>Catalogue</b></html>");
		panSearch = new JPanel();
		panSearch.setLayout(new GridLayout(1,1));
		panSearch.setBorder(bord);
		panSearch.setOpaque(false);
		panSearch.add(searchText);
		panSearch.add(btn);
		
		titreT = new String[]{"Titre", "Auteur", "Editeur", "Langue", "Genre", "Disponible"};
        ob = new Object[150][6];
        t = new JTable(ob,titreT);
        t.getTableHeader().setBackground(new Color(191, 187, 187 ));
        t.setOpaque(false);
        scrol = new JScrollPane(t);
        scrol.setPreferredSize(new Dimension(570, 440));
        
        lister();
		
        main = this;
		main.setLayout(new BorderLayout());
		main.setPreferredSize(new Dimension(580,460));
		main.setBackground(Color.decode("#ececec"));
		main.add(panSearch, BorderLayout.NORTH);
		main.add(scrol, BorderLayout.CENTER);
	}
	
	public void lister(){
		try
        {
            con = new connection();
            stat = con.getStatement();
            req="select * FROM livre";
            rese = stat.executeQuery(req);
            int i=0;
            ob=new Object[150][6];
            while(rese.next())
            {
                ob[i][0]=rese.getString("titre");
                ob[i][1]=rese.getString("auteur");
                ob[i][2]=rese.getString("editeur");
                ob[i][3]=rese.getString("langue");
                ob[i][4]=rese.getString("categorie");
                ob[i][5]=rese.getString("disponibilite");
                i++;
            }
            t.setModel(new javax.swing.table.DefaultTableModel(ob,titreT));
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,"Le listage n'a pas �t� fait!");
        }
	}
	
	public void rechercher(){
		if(searchText.getText().equals("") || searchText.getText().equals("Tapez le nom du livre")){
			
		}else{
			try{
				con = new connection();
				stat = con.getStatement();
				req = "select * from livre where titre ='"+searchText.getText()+"'";
				rese = stat.executeQuery(req);
				int i=0;
		        ob=new Object[150][6];
		        while(rese.next())
		        {
		           ob[i][0]=rese.getString("titre");
		           ob[i][1]=rese.getString("auteur");
		           ob[i][2]=rese.getString("editeur");
		           ob[i][3]=rese.getString("langue");
		           ob[i][4]=rese.getString("categorie");
		           ob[i][5]=rese.getString("disponibilite");
		           i++;
		        }
		        t.setModel(new javax.swing.table.DefaultTableModel(ob,titreT));			
			}catch(SQLException e){
				JOptionPane.showMessageDialog(null,""+e.getMessage());
			}
		}
	}
	
	public void actionPerformed(ActionEvent e){
		if(e.getSource() == btn){
			rechercher();
		}
	}
}
