package eLib;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.NumberFormatter;

import eLib.komponenMakeOver.buttonMakeOver;

@SuppressWarnings("serial")
public class Subscriber extends JDialog implements ActionListener{
JLabel title, icon, id_abonne, lbId, nom, email, sexe, adresse, image, cd_PIN, lbPeriod;
JTextField txnom, txadresse, txemail;
JPanel panID, panTitle, panIcon, main, nord, centre, ouest, sud, panGrid, panGridCard, panall;
TitledBorder bord, bord1;
JButton can, ok;
NumberFormatter formatter, formatter1;
JFormattedTextField txCd_PIN;
@SuppressWarnings("rawtypes")
JComboBox CBsex, cbPeriod;
String sex[], cb, period[], type = "User";
buttonMakeOver btn, btn1;
SimpleDateFormat sdf;

Random random;
static int nb, cpt = 0, borneInf = 10000000, borneSup = 99999999;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Subscriber(JFrame login){
		super(login);
		setUndecorated(true);
		setVisible(true);		
		setSize(600, 380);
		setLocationRelativeTo(null);
		setShape(new RoundRectangle2D.Double(1, 1, 600, 380, 15, 15));
		
		title = new JLabel("Informations requises");
		title.setFont(new Font("Sans-serif", 0, 16));
		title.setOpaque(false);
		
		panTitle = new JPanel();
		panTitle.setOpaque(false);
		panTitle.add(title);
		
		icon = new JLabel(new ImageIcon(getClass().getResource("po.png")));
        icon.setToolTipText("Fermer");
		icon.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				dispose();
			}
		});
		
		panIcon = new JPanel();
		panIcon.setOpaque(false);
		panIcon.add(icon);
		
		nord = new JPanel();
		nord.setLayout(new BorderLayout());
		nord.setPreferredSize(new Dimension(600, 30));
		nord.setBackground(Color.decode("#afafaf"));
		nord.add(panTitle, BorderLayout.CENTER);
		nord.add(panIcon, BorderLayout.EAST);
		
		random = new Random();
		nb = borneInf + random.nextInt(borneSup-borneInf);
		
		lbId = new JLabel("<html><b>"+nb+"</b></html>");
		panID = new JPanel();
		panID.add(lbId);
		
		image = new JLabel(new ImageIcon(getClass().getResource("BarCode.png")));
		ouest = new JPanel();
		ouest.setLayout(new BorderLayout());
		ouest.add(image, BorderLayout.NORTH);
		ouest.add(panID, BorderLayout.CENTER);			
		
		
		nom = new JLabel("<html><b>Nom :</b></html>");
		txnom = new JTextField();
		
		formatter = new NumberFormatter(new java.text.DecimalFormat("#0"));
	    formatter.setAllowsInvalid(false);
	    
		email = new JLabel("<html><b>Email :</b></html>");
		txemail = new JTextField();
		txemail.setText("you@example.com");
		txemail.setForeground(Color.GRAY);
		txemail.addFocusListener(new FocusListener() {
	        @Override
	        public void focusGained(FocusEvent e) {
	            if (txemail.getText().equals("you@example.com")) {
	            	txemail.setText("");
	            	txemail.setForeground(Color.BLACK);
	            }
	        }
	        @Override
	        public void focusLost(FocusEvent e) {
	            if (txemail.getText().isEmpty()) {
	            	txemail.setForeground(Color.GRAY);
	            	txemail.setText("you@example.com");
	            }
	        }
	    });
		
		
		sexe = new JLabel("<html><b>Sexe :</b></html>");
		sex = new String[]{"Sexe", "Masculin", "Feminin"};
		CBsex = new JComboBox(sex);
		
		adresse = new JLabel("<html><b>Adresse :</b></html>");
		txadresse = new JTextField();
		
		sdf = new SimpleDateFormat("dd/MM/yyyy");
		
		bord = new TitledBorder("<html><br><b>Enregister abonne(e)</b></html>");
		
		panGrid = new JPanel();
		panGrid.setBorder(bord);
		panGrid.setOpaque(false);
		panGrid.setLayout(new GridLayout(4,2));
		panGrid.add(nom);
		panGrid.add(txnom);
		panGrid.add(email);
		panGrid.add(txemail);
		panGrid.add(sexe);
		panGrid.add(CBsex);
		panGrid.add(adresse);
		panGrid.add(txadresse);
		
		formatter1 = new NumberFormatter(new java.text.DecimalFormat("#0"));
	    formatter1.setAllowsInvalid(false);
	    
		cd_PIN = new JLabel("<html><b>Code PIN :</b></html>");
		txCd_PIN = new JFormattedTextField();
		txCd_PIN.setFormatterFactory(new DefaultFormatterFactory(formatter1));
		
		lbPeriod = new JLabel("<html><b>Periode validite :</b></html>");
		period = new String[]{"Periode validite", "15 jours", "20 jours", "25 jours", "30 jours"};
		cbPeriod = new JComboBox(period);
		
		bord1 = new TitledBorder("<html><br><b>Carte magnetique</b></html>");
		
		panGridCard = new JPanel();
		panGridCard.setBorder(bord1);
		panGridCard.setOpaque(false);
		panGridCard.setLayout(new GridLayout(2,2));
		panGridCard.add(cd_PIN);
		panGridCard.add(txCd_PIN);
		panGridCard.add(lbPeriod);
		panGridCard.add(cbPeriod);
		
		panall = new JPanel();
		panall.setLayout(new BorderLayout());
		panall.setPreferredSize(new Dimension(450,300));
		panall.setOpaque(false);
		panall.add(panGrid, BorderLayout.NORTH);
		panall.add(panGridCard, BorderLayout.SOUTH);
		
		centre = new JPanel();
		centre.setBackground(Color.decode("#ececec"));
		centre.add(panall);
		
		
		
		btn = new eLib.komponenMakeOver.buttonMakeOver();
		btn.setForeground(new java.awt.Color(0, 0, 0));
		btn.setText("    Annuler   ");
		btn.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
		btn.addActionListener(this);
		btn.setBounds(-10, 0, 420, 80);
		
		btn1 = new eLib.komponenMakeOver.buttonMakeOver();
		btn1.setForeground(Color.decode("#3193fe"));
		btn1.setText("    Sauvegarder   ");
		btn1.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
		btn1.addActionListener(this);
		btn1.setBounds(-10, 0, 420, 80);
		
		
		sud = new JPanel();
		sud.setPreferredSize(new Dimension(600, 45));	
		sud.add(btn);
		sud.add(btn1);
		
		main = new JPanel();
		main.setLayout(new BorderLayout());
		
		main.add(nord, BorderLayout.NORTH);
		main.add(ouest, BorderLayout.WEST);
		main.add(centre, BorderLayout.CENTER);
		main.add(sud, BorderLayout.SOUTH);
		
		add(main);
		
		validate();
	}
	
	public void Inserer(){
		cb = CBsex.getSelectedItem().toString();
		if(txnom.getText().equals("") || txemail.getText().equals("") || txemail.getText().equals("you@example.com") || cb.equals("Sexe") || txadresse.getText().equals("") || txCd_PIN.getText().equals("") || cbPeriod.getSelectedItem().equals("Periode validite")){
			JOptionPane.showMessageDialog(null, "Tous les champs sont obligatoires.");
		}else{
			if(txCd_PIN.getText().length()!=4){
				JOptionPane.showMessageDialog(null, "Votre Code PIN doit contenir 4 chiffres.");
			}else{
				boolean status = valide.valider(txemail.getText());
				if(status){
					abonner.ins_Abonne(nb, txnom.getText(), txemail.getText(), cb, txadresse.getText(), type, sdf.format(new Date()), cpt);
					carte.ins_Carte(Integer.parseInt(txCd_PIN.getText()), nb, cbPeriod.getSelectedItem().toString(), "Active");
					JOptionPane.showMessageDialog(null, "Enregistrement reussi!!!");
					dispose();
					new Print_Carte_Panel();
				}else{
					JOptionPane.showMessageDialog(null,"Votre email est invalide!");
				}
			}			
		}
	}
	
	public void actionPerformed(ActionEvent e){
		if(e.getSource() == btn){
			dispose();
			new login(null);
		}
		
		if(e.getSource() == btn1){
			Inserer();
			
		}
	}
}
