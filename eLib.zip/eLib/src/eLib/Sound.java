package eLib;

import java.io.IOException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

public class Sound {
	public void Wrong(){
		try {	         
	         AudioInputStream audioIn = AudioSystem.getAudioInputStream(getClass().getResource("Low_Battery.wav"));
	         Clip clip = AudioSystem.getClip();
	         clip.open(audioIn);
	         clip.start();
	      } catch (UnsupportedAudioFileException e) {
	    	  e.printStackTrace();
	         System.out.println(""+ e.getMessage());
	      } catch (IOException e) {
	         e.printStackTrace();
	         System.out.println(""+ e.getMessage());
	      } catch (LineUnavailableException e) {
	         e.printStackTrace();
	         System.out.println(""+ e.getMessage());
	      }
	}
	
	public void Right(){
		try {	         
	         AudioInputStream audioIn = AudioSystem.getAudioInputStream(getClass().getResource("notif_sound.wav"));
	         Clip clip = AudioSystem.getClip();
	         clip.open(audioIn);
	         clip.start();
	      } catch (UnsupportedAudioFileException e) {
	    	  e.printStackTrace();
	         System.out.println(""+ e.getMessage());
	      } catch (IOException e) {
	         e.printStackTrace();
	         System.out.println(""+ e.getMessage());
	      } catch (LineUnavailableException e) {
	         e.printStackTrace();
	         System.out.println(""+ e.getMessage());
	      }
	}
}
