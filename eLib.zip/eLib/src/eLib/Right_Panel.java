package eLib;

import java.awt.Dimension;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class Right_Panel extends JPanel{
JLabel Image;
JPanel main;
	public Right_Panel(){
		Image = new JLabel(new ImageIcon(getClass().getResource("one.png")));
		Image.setOpaque(false);
		
		main = this;
		main.setPreferredSize(new Dimension(580,460));
		main.setOpaque(false);
		main.add(Image);
	}
}
