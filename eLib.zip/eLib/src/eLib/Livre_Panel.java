package eLib;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.text.SimpleDateFormat;
import java.util.Random;

import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.NumberFormatter;

import com.toedter.calendar.JDateChooser;

import eLib.komponenMakeOver.buttonMakeOver;

@SuppressWarnings("serial")
public class Livre_Panel extends JPanel implements ActionListener{
	JPanel main, panAll, panDes, panGrid, panButton;
	JLabel lbISBN, lbTitre, lbAuteur, lbEditeur, lbCategorie, lbPage, lbLangue, lbDescription, lbDate;
	JTextField txTitre, txAuteur, txEditeur, txDate;
	JFormattedTextField txPage, txISBN;
	JDateChooser chooser;
	SimpleDateFormat sdf;
	TitledBorder bord, bord1;
	JTextArea txDescription;
	@SuppressWarnings("rawtypes")
	JComboBox CbLangue, CbCategorie;
	String langue[], categorie[];
	NumberFormatter formatter, formatter1;
	
	buttonMakeOver btn, btn1;
	
	Random random1, random2;
	int nb1, nb2, borneInf1 = 1000000, borneSup1 = 9999999, borneInf2 = 100000, borneSup2 = 999999;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Livre_Panel(){
		
		bord = new TitledBorder("<html><br><b>Enregistrement ouvrage</b></html>");
		
		formatter1 = new NumberFormatter(new java.text.DecimalFormat("#0"));
	    formatter1.setAllowsInvalid(false);
		
		lbISBN = new JLabel("ISBN :");
		txISBN = new JFormattedTextField();
		txISBN.setFormatterFactory(new DefaultFormatterFactory(formatter1));
		
		
		lbTitre = new JLabel("Titre :");
		txTitre = new JTextField();
		
		lbAuteur = new JLabel("Auteur :");
		txAuteur = new JTextField();
		
		lbEditeur  = new JLabel("Editeur :");
		txEditeur = new JTextField();
		
		lbDate = new JLabel("Date Edition:");
		txDate = new JTextField("dd/MM/YYYY");
		txDate.setForeground(Color.GRAY);
		txDate.setFocusable(false);
		txDate.addFocusListener(new FocusListener() {
	        @Override
	        public void focusGained(FocusEvent e) {
	            if (txDate.getText().equals("dd/MM/YYYY")) {
	            	txDate.setText("");
	            	txDate.setForeground(Color.BLACK);
	            }
	        }
	        @Override
	        public void focusLost(FocusEvent e) {
	            if (txDate.getText().isEmpty()) {
	            	txDate.setForeground(Color.GRAY);
	            	txDate.setText("dd/MM/YYYY");
	            }
	        }
	    });
		
		chooser = new JDateChooser();
	    chooser.add(txDate);
	    chooser.addPropertyChangeListener("date",new PropertyChangeListener  () { 
	         public void propertyChange(PropertyChangeEvent e){
	        	 if(e.getSource() == chooser){
	    	    	 sdf = new SimpleDateFormat("dd/MM/yyyy");
	    	    	 txDate.setText(sdf.format(chooser.getDate()));
	    	     }
	    	 }
	    	 });
		
	    formatter = new NumberFormatter(new java.text.DecimalFormat("#0"));
	    formatter.setAllowsInvalid(false);
	    
		lbPage = new JLabel("Nbre de pages :");
		txPage = new JFormattedTextField();
		txPage.setFormatterFactory(new DefaultFormatterFactory(formatter));
		
		lbLangue = new JLabel("Langue :");
		langue = new String[]{"Langue", "Anglais", "Creole",  "Espagnol", "Francais"};
		CbLangue = new JComboBox(langue);	
		
		lbCategorie = new JLabel("Categorie :");
		categorie = new String[]{"Categorie", "Arts & Culture", "Bande Dessinee, Comics & Manga", "Documents & Medias", "Enseignement & Education", "Erotisme", "Esoterisme", "Histoire & Geographie", "Jeunesse", "Litterature & Lettres", "Loisirs, Vie pratique & Societe", "Religions & Spiritualite", "Romans & Fictions", "Sante & Bien-etre", "Sciences Humaines", "Sciences & Techniques", "Sciences Sociales"};
		CbCategorie = new JComboBox(categorie);
		
		lbDescription = new JLabel("Description :");
		txDescription = new JTextArea();
		txDescription.setLineWrap(true);
		txDescription.setPreferredSize(new Dimension(100,140));
		
		panGrid = new JPanel();
		panGrid.setOpaque(false);
		panGrid.setPreferredSize(new Dimension(560,180));
		panGrid.setBorder(bord);
		panGrid.setLayout(new GridLayout(4, 4, 3, 2));
		panGrid.add(lbISBN);
		panGrid.add(txISBN);
		panGrid.add(lbTitre);
		panGrid.add(txTitre);
		panGrid.add(lbAuteur);
		panGrid.add(txAuteur);
		panGrid.add(lbEditeur);
		panGrid.add(txEditeur);
		panGrid.add(lbDate);
		panGrid.add(chooser);
		panGrid.add(lbPage);
		panGrid.add(txPage);
		panGrid.add(lbLangue);
		panGrid.add(CbLangue);
		panGrid.add(lbCategorie);
		panGrid.add(CbCategorie);
		
		bord1 = new TitledBorder("<html><br><b>Description ouvrage</b></html>");
		panDes = new JPanel();
		panDes.setOpaque(false);
		panDes.setLayout(new GridLayout(1, 1));
		panDes.setBorder(bord1);
		panDes.add(txDescription);
	
		btn = new eLib.komponenMakeOver.buttonMakeOver();
		btn.setForeground(new java.awt.Color(0, 0, 0));
		btn.setText("Annuler");
		btn.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
		btn.addActionListener(this);
		btn.setBounds(-10, 0, 420, 80);
		
		btn1 = new eLib.komponenMakeOver.buttonMakeOver();
		btn1.setForeground(Color.decode("#3193fe"));
		btn1.setText("Sauvegarder");
		btn1.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
		btn1.addActionListener(this);
		btn1.setBounds(-10, 0, 420, 80);
		
		panButton = new JPanel();
		panButton.setPreferredSize(new Dimension(580,50));
		panButton.add(btn);
		panButton.add(btn1);
		
		panAll = new JPanel();
		panAll.setOpaque(false);
		panAll.setLayout(new BorderLayout());
		panAll.add(panGrid, BorderLayout.NORTH);
		panAll.add(panDes, BorderLayout.CENTER);
		panAll.add(panButton, BorderLayout.SOUTH);

		
		main = this;
		main.setPreferredSize(new Dimension(580,460));
		main.setBackground(Color.decode("#ececec"));
		main.add(panAll);
		main.add(panButton);
		
	}
	
	public void Inserer(){
		if(txISBN.getText().equals("") || txTitre.getText().equals("") || txAuteur.getText().equals("") || txEditeur.getText().equals("") || txDate.getText().equals("") || txDate.getText().equals("dd/MM/YYYY") || txPage.getText().equals("") || CbLangue.getSelectedItem().equals("Langue") || CbCategorie.getSelectedItem().equals("Categorie") || txDescription.getText().equals("")){
			JOptionPane.showMessageDialog(null, "Tous les champs sont obligatoires.");
		}else{
			if(txISBN.getText().length() != 13){
				JOptionPane.showMessageDialog(null, "L'ISBN doit contenir 13 chiffres.");
			}else{
			Livre.ins_Livre(txISBN.getText(), txTitre.getText(), txAuteur.getText(), txEditeur.getText(), txDate.getText(), txPage.getText(), CbLangue.getSelectedItem().toString(), CbCategorie.getSelectedItem().toString(), txDescription.getText(), "Oui");
			JOptionPane.showMessageDialog(null, "Enregistrement reussi!!!");
			clean();
			}
		}
	}
	
	public void clean(){
		txISBN.setText("");
		txTitre.setText("");
		txAuteur.setText("");
		txEditeur.setText("");
		txDate.setText("dd/MM/YYYY");
		txDate.setForeground(Color.GRAY);
		txPage.setText("");
		CbLangue.setSelectedItem("Langue");
		CbCategorie.setSelectedItem("Categorie");
		txDescription.setText("");
	}
	
	public void actionPerformed(ActionEvent e){
		if(e.getSource() == btn){
			clean();
		}
		
		if(e.getSource() == btn1){
			Inserer();
		}
	}
}
