package eLib;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.geom.RoundRectangle2D;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import eLib.komponenMakeOver.buttonMakeOver;



@SuppressWarnings("serial")
public class login extends JDialog implements ActionListener{
	JPanel nord, centre, sud, panbout, panall, pangrid, pansud, panLog;
	JLabel im, titre, lbUser, lbPass, icon, link, loggin;
	static JTextField txUser;
	JPasswordField txPass;
	Image img;
	buttonMakeOver can, ok;
	
	String req, nom;
	
	private int posX = 0;
    private int posY = 0;
    
    private connection con;
    private Statement stat;
    private ResultSet rese;
    
    static String username, Tip;
    static int id;
    
	public login(JFrame lanceur)
	{
		super(lanceur);
		setUndecorated(true);
		setVisible(true);		
		setSize(450, 230);
		setLocationRelativeTo(null);
		setShape(new RoundRectangle2D.Double(1, 1, 450, 230, 15, 15));
		
		loggin = new JLabel("<html><h3>Login</h3></html>");
		panLog = new JPanel();
		panLog.setOpaque(false);
		panLog.add(loggin);
        
        icon = new JLabel(new ImageIcon(getClass().getResource("po.png")));
        icon.setToolTipText("Fermer");
		icon.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				dispose();
			}
		});
		
		panbout = new JPanel();
		panbout.setOpaque(false);
		panbout.setLayout(new FlowLayout());
		panbout.add(icon);
		
		nord = new JPanel();
		nord.setLayout(new BorderLayout());
		nord.setPreferredSize(new Dimension(450, 30));
		nord.setBackground(Color.decode("#afafaf"));
		nord.add(panbout, BorderLayout.EAST);
		//nord.add(panLog, BorderLayout.CENTER);
		
		
		//panel central...		
		centre = new JPanel();
		centre.setLayout(new FlowLayout());
		centre.setBackground(Color.decode("#ececec"));
		centre.setPreferredSize(new Dimension(450, 170));
		
		//Element flow a gauche..
		im = new JLabel(new ImageIcon(getClass().getResource("key.png")));
		im.setPreferredSize(new Dimension(70, 70));
		im.setOpaque(false);
		// End..
		
		
		//Element flow a droite...		
		panall = new JPanel();
		panall.setLayout(new BorderLayout());
		panall.setPreferredSize(new Dimension(370, 170));		
		panall.setOpaque(false);
		
		titre = new JLabel("<html>Saisissez votre nom d'utilisateur et code PIN<br> pour autoriser l'acces</html>");
		titre.setFont(new java.awt.Font("sans-serif", 1, 15));
		titre.setPreferredSize(new Dimension(370,65));
		
		pangrid = new JPanel();
		pangrid.setLayout(new GridLayout(2,2));
		pangrid.setOpaque(false);
		pangrid.setPreferredSize(new Dimension(370,100));
		
		lbUser = new JLabel("Nom d'utilisateur :");
		lbPass = new JLabel("Code PIN :");
		
		txUser = new JTextField(50);
		
		txPass = new JPasswordField();
		txPass.setEchoChar('.');
		txPass.setFont(new java.awt.Font("sans-serif", Font.BOLD, 15));

		
		
		pangrid.add(lbUser);
		pangrid.add(txUser);
		pangrid.add(lbPass);
		pangrid.add(txPass);
		
		pansud = new JPanel();
		pansud.setPreferredSize(new Dimension(370, 45));
		pansud.setOpaque(false);
		pansud.setLayout(new FlowLayout());
		
		link = new JLabel("<html><b>Vous n'avez pas de Compte? <u>Inscrivez-vous!</u></b></html>");
		link.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				dispose();
				new Subscriber(null);
			}
		});
		
		
		can = new eLib.komponenMakeOver.buttonMakeOver();
		can.setForeground(new java.awt.Color(0, 0, 0));
		can.setText("Annuler");
		can.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
		can.addActionListener(this);
		can.setBounds(-10, 0, 420, 80);
		
		ok = new eLib.komponenMakeOver.buttonMakeOver();
		ok.setForeground(Color.decode("#3193fe"));
		ok.setText("Connecter");
		ok.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
		ok.addActionListener(this);
		ok.setBounds(-10, 0, 420, 80);
		
		pansud.add(link);
		
		panall.add(titre, BorderLayout.NORTH);
		panall.add(pangrid, BorderLayout.CENTER);
		panall.add(pansud, BorderLayout.SOUTH);
		//End element a droite...
		
		//Ajout des elements dans pannel central...
		centre.add(im);
		centre.add(panall);
		//End...	
		
		//Panel sud...
		sud = new JPanel();
		sud.setPreferredSize(new Dimension(450, 45));	
		sud.add(can);
		sud.add(ok);
		//End...
		
		setLayout(new BorderLayout());		
		addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                posX = e.getX();
                posY = e.getY();
            }
        });		
		addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int depX = e.getX() - posX;
                int depY = e.getY() - posY;
                setLocation(getX()+depX, getY()+depY);
            }
        });
		
		add(nord, BorderLayout.NORTH);
		add(centre, BorderLayout.CENTER);
		add(sud, BorderLayout.SOUTH);
		
		validate();
	}
	
	@SuppressWarnings("deprecation")
	public void log(){
		try{
		con = new connection();
		stat = con.getStatement();
		req = "select abonne.nom, abonne.id_abonne, abonne.typeUser, carte.code_PIN, carte.etat from abonne inner join carte on carte.id_abonne = abonne.id_abonne where nom ='"+txUser.getText()+"' and code_PIN ="+txPass.getText();
		rese = stat.executeQuery(req);
		if(!rese.next()){
			new Sound().Wrong();			
		}else{
			username = rese.getString("nom");
			id = rese.getInt("id_abonne");
			Tip = rese.getString("typeUser");			
			new Sound().Right();
			new Lanceur();
			dispose();			
		}
		}catch(SQLException e){
			JOptionPane.showMessageDialog(null,""+e.getMessage());
		}
	}

	@SuppressWarnings("deprecation")
	public void actionPerformed(ActionEvent e){
		if(e.getSource() == can){
			clean();
		}
		
		if(e.getSource() == ok){
			if(txUser.getText().equals("") || txPass.getText().equals("")){
				
			}else{
				log();
			}			
		}
	}
	
	
	public void clean(){
		txUser.setText("");
		txPass.setText("");
	}
}
