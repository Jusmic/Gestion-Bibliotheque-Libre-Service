package eLib;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class Livre {
String isbn, titre, auteur, editeur, dateEdition, page, langue, categorie, description, disponibilite;

private static connection con;
private static Statement stat;
private static ResultSet rese;

static String req;

	public Livre(String isbn, String titre, String auteur, String editeur, String dateEdition, String page, String langue, String categorie, String description, String disponibilite){
		this.isbn = isbn;
		this.titre = titre;
		this.auteur = auteur;
		this.editeur = editeur;
		this.dateEdition = dateEdition;
		this.page = page;
		this.langue = langue;
		this.categorie = categorie;		
		this.description = description;
		this.disponibilite = disponibilite;		
	}
	
	//Accesseurs...
	public String getIsbn() {
		return isbn;
	}
	public String getTitre() {
		return titre;
	}
	public String getAuteur() {
		return auteur;
	}
	public String getEditeur() {
		return editeur;
	}
	public String getDateEdition() {
		return dateEdition;
	}
	public String getPage() {
		return page;
	}
	public String getLangue() {
		return langue;
	}
	public String getCategorie() {
		return categorie;
	}
	public String getDescription() {
		return description;
	}
	public String getDisponibilite() {
		return disponibilite;
	}
	
	//Mutateurs...
	public void setTitre(String titre) {
		this.titre = titre;
	}
	public void setAuteur(String auteur) {
		this.auteur = auteur;
	}
	public void setEditeur(String editeur) {
		this.editeur = editeur;
	}
	public void setDateEdition(String dateEdition) {
		this.dateEdition = dateEdition;
	}	
	public void setPage(String page) {
		this.page = page;
	}
	public void setLangue(String langue) {
		this.langue = langue;
	}
	public void setCategorie(String categorie) {
		this.categorie = categorie;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setDisponibilite(String disponibilite) {
		this.disponibilite = disponibilite;
	}
	
	public static void ins_Livre(String isbn, String titre, String auteur, String editeur, String dateEdition, String page, String langue, String categorie, String description, String disponibilite){
		try {
			con = new connection();
			stat = con.getStatement();
			req = "SELECT * FROM livre WHERE ISBN = '"+isbn+"'";			
			rese = stat.executeQuery(req);
			if(rese.next()){
				JOptionPane.showMessageDialog(null, "Ce code �xiste d�j� dans notre archive.");
			}else{
				req = "INSERT INTO livre VALUES("+isbn+", '"+titre+"', '"+auteur+"', '"+editeur+"', '"+dateEdition+"', '"+page+"', '"+langue+"', '"+categorie+"', '"+description+"', '"+disponibilite+"')";
				stat.executeUpdate(req);
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
			e.printStackTrace();
		}
	}
}
