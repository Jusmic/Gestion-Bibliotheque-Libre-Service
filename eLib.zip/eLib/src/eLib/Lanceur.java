package eLib;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;


@SuppressWarnings("serial")
public class Lanceur extends JFrame{
	JPanel main, panLeft, pansud, paninfo, pantitle, icone, panTop;
	JLabel info, icon, titre;	
	Image image;
	static JPanel panCenter;
	
	public Lanceur(){
		setSize(800, 500);
		setUndecorated(true);
		setLocationRelativeTo(null);
		setVisible(true);
		
		setIconImage(new ImageIcon(getClass().getResource("ico.png")).getImage());
		
		initCompo();
		
		validate();
	}
	
	public void call(){
		new login(this);
	}
	
	public static void main(String [] calij){
		try {
	        for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
	            if ("Nimbus".equals(info.getName())) {
	                UIManager.setLookAndFeel(info.getClassName());
	                break;
	            }
	        }
	    } catch (ClassNotFoundException ex) {	         
	    } catch (InstantiationException ex) {	         
	    } catch (IllegalAccessException ex) {	         
	    } catch (UnsupportedLookAndFeelException ex) {	       
	    }	     
	    java.awt.EventQueue.invokeLater(new Runnable() {
		    public void run() {
		       	new Principale(null);
		    }
	    });
	}
	
	public void initCompo(){
		new checkDay().checkLivreDay();
		new checkDay().checkCartePeriod();
		
		icon = new JLabel(new ImageIcon(getClass().getResource("min.png")));
		icon.setOpaque(false);
		icon.setToolTipText("Fermer");
		icon.addMouseListener(new MouseAdapter(){
            public void mousePressed(MouseEvent e){
            	System.exit(0);
            }
		});
			
		icone = new JPanel();
		icone.setOpaque(false);
		icone.add(icon);
		
		
		titre = new JLabel("Bibliotheque Libre-Service");
		titre.setFont(new Font("Sans-serif", 0, 16));
		titre.setOpaque(false);
				
		
		pantitle = new JPanel();
		pantitle.setPreferredSize(new Dimension(titre.getWidth(), 35));
		pantitle.setOpaque(false);
		pantitle.add(titre);
		
		panTop =  new JPanel(){
			protected void paintComponent(Graphics gra){
	             super.paintComponent(gra);
	             try{	                 
	                 image = ImageIO.read(getClass().getResource("fnd.jpg"));
	             }catch(Exception rx){}
	            gra.drawImage(image,0,0,null);
	            }
		};
		panTop.setPreferredSize(new Dimension(800,30));
		panTop.setLayout(new BorderLayout());
		panTop.add(pantitle, BorderLayout.CENTER);
		panTop.add(icone, BorderLayout.EAST);
		
      //Quelques infos...
     	info = new JLabel("Copyright | All right reserved | eLib");
     	info.setFont(new Font("Sans-serif", 0, 14));
      	info.setOpaque(false);
      //End...
      		
      	paninfo = new JPanel();
      	paninfo.setOpaque(false);
      	paninfo.add(info);
      		
      	//Panel sud...
      	pansud = new JPanel(){
			protected void paintComponent(Graphics gra){
	             super.paintComponent(gra);
	             try{	                 
	                 image = ImageIO.read(getClass().getResource("fnd.jpg"));
	             }catch(Exception rx){}
	            gra.drawImage(image,0,0,null);
	            }
		};
      	pansud.setPreferredSize(new Dimension(800, 30));
      	pansud.setLayout(new BorderLayout());
      	pansud.add(paninfo, BorderLayout.CENTER);
      	//End panel sud...
		
        
        panLeft = new JPanel();
        panLeft.setOpaque(false);
        add_Left_Panel();
        
        panCenter =new JPanel();
        if(login.Tip.equals("User")){
        	add_Right_Panel();
        }else{
        	call_Ouvrage_Pan();
        }        
        
		main = new JPanel();
		main.setLayout(new BorderLayout());
		main.add(panTop, BorderLayout.NORTH);
		main.add(panLeft, BorderLayout.WEST);
		main.add(panCenter, BorderLayout.CENTER);
		main.add(pansud, BorderLayout.SOUTH);
		
		add(main);
	}
	
	public void add_Left_Panel(){
		panLeft.removeAll();
		panLeft.add(new Left_Panel());
		setVisible(true);
	}
	
	public void add_Right_Panel(){
		panCenter.removeAll();
		panCenter.add(new Right_Panel());
		setVisible(true);
	}
	
	public void call_Ouvrage_Pan(){
		panCenter.removeAll();
		panCenter.add(new Livre_Panel());
		setVisible(true);
	}
}
