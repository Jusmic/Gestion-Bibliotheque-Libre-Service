package eLib;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JOptionPane;

public class checkDay {
SimpleDateFormat sdf;
Date today, before;
float jour;

private static connection con;
private static Statement stat;
private static ResultSet rese;

static String req;
String aujour, desac = "Desactive", periode;
long diff;
int day;

	public void getDateAndDay(int Code){
		sdf = new SimpleDateFormat("dd/MM/yyyy");
		aujour = sdf.format(new Date());
		try {
			con = new connection();
			stat = con.getStatement();
			req = "SELECT dateEmprunt FROM emprunt WHERE code_PIN = "+Code;			
			rese = stat.executeQuery(req);
			if(rese.next()){
				try {
					before = sdf.parse(rese.getString("dateEmprunt"));
					today = sdf.parse(aujour);
					diff = today.getTime() - before.getTime();
				    jour = (diff / (1000*60*60*24));
				    day = (int)jour;
				    if(day > 45){
				    	req = "update carte set etat = '"+desac+"' where code_PIN = "+Code;
				    	stat.executeUpdate(req);
				    	JOptionPane.showMessageDialog(null, "Vous avez passe plus de 45 jours avec ce livre, votre carte est donc suspendue, SVP passez au service client pour la reactivation !");
				    }
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
			e.printStackTrace();
		}
	}

	public void getCodePin(){
		try {
			con = new connection();
			stat = con.getStatement();
			req = "SELECT code_PIN FROM carte WHERE id_abonne = "+login.id;			
			rese = stat.executeQuery(req);
			if(rese.next()){
				getDateAndDay(rese.getInt("code_PIN"));
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
			e.printStackTrace();
		}
	}

	public void checkLivreDay(){
		try {
			con = new connection();
			stat = con.getStatement();
			req = "SELECT compteur FROM abonne WHERE id_abonne = "+login.id;			
			rese = stat.executeQuery(req);
			if(rese.next()){
				if(rese.getInt("compteur")>0){
					getCodePin();
				}
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
			e.printStackTrace();
		}
	}
	
	/////////////////////////////////////////////////////////////////////////////////
	
	public void getDay(int Code){
		sdf = new SimpleDateFormat("dd/MM/yyyy");
		aujour = sdf.format(new Date());
		try {
			con = new connection();
			stat = con.getStatement();
			req = "select abonne.dateEnr, carte.period from abonne inner join carte on carte.id_abonne = abonne.id_abonne where code_PIN = "+Code;			
			rese = stat.executeQuery(req);
			if(rese.next()){
				try {
					before = sdf.parse(rese.getString("dateEnr"));
					today = sdf.parse(aujour);
					diff = today.getTime() - before.getTime();
				    jour = (diff / (1000*60*60*24));
				    day = (int)jour;
				    
				    periode = rese.getString("period").substring(0, 2);
				    if(day > Integer.parseInt(periode)){
				    	req = "update carte set etat = '"+desac+"' where code_PIN = "+Code;
				    	stat.executeUpdate(req);
				    	JOptionPane.showMessageDialog(null, "La p�riode de votre carte est termin�,e, SVP passez au service client pour la r�activation !");
				    }
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
			e.printStackTrace();
		}
	}
	
	
	public void checkCartePeriod(){
		try {
			con = new connection();
			stat = con.getStatement();
			req = "SELECT code_PIN FROM carte WHERE id_abonne = "+login.id;			
			rese = stat.executeQuery(req);
			if(rese.next()){
				getDay(rese.getInt("code_PIN"));
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
			e.printStackTrace();
		}
	}
	
	
}
