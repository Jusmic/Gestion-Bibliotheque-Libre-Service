package eLib;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import eLib.komponenMakeOver.buttonMakeOver;

@SuppressWarnings("serial")
public class Print_Carte_Panel extends JDialog implements ActionListener{
	JPanel main, panAll, space, panImg, panSex, ouest, centre, sud, spaceWest, spaceEast, panBar, panId;
	JLabel img, nom, getNom, email, getEmail, sexe, getSexe, adresse, getAdresse, barCode, lbId;
	Image image;
	buttonMakeOver btn, btn1;
	
	private static connection con;
	private static Statement stat;
	private static ResultSet rese;

	static String req;

	public Print_Carte_Panel(){
		setUndecorated(true);
		setVisible(true);	
		setSize(434,316);
		setLocationRelativeTo(null);
		setShape(new RoundRectangle2D.Double(1, 1, 434, 316, 15, 15));
		
		
		space = new JPanel();
		space.setOpaque(false);
		space.setPreferredSize(new Dimension(434, 88));
		
		img = new JLabel(new ImageIcon(getClass().getResource("logo_carte.png")));
		panImg = new JPanel();
		panImg.setOpaque(false);
		panImg.setPreferredSize(new Dimension(121, 56));
		panImg.add(img);
		
		nom = new JLabel("<html><b>Nom complet :</b></html>");
		nom.setFont(new Font("Sans-serif", 1, 14));
		getNom = new JLabel("blabla");
		
		email = new JLabel("<html><b>Email :</b></html>");
		email.setFont(new Font("Sans-serif", 1, 14));
		getEmail = new JLabel("blabla");
		
		sexe = new JLabel("<html><b>Sexe :</b></html>");
		sexe.setFont(new Font("Sans-serif", 1, 14));
		getSexe = new JLabel("hbhbgg");
		adresse = new JLabel("<html><b>Adresse :</b></html>");
		adresse.setFont(new Font("Sans-serif", 1, 14));
		getAdresse = new JLabel("Baljjsjdsj");
		
		ouest = new JPanel();
		ouest.setOpaque(false);
		ouest.setLayout(new GridLayout(6, 1));
		ouest.add(nom);
		ouest.add(getNom);
		ouest.add(email);
		ouest.add(getEmail);
		ouest.add(adresse);
		ouest.add(getAdresse);
		
		panSex = new JPanel();
		panSex.setOpaque(false);
		panSex.setLayout(new FlowLayout());
		panSex.add(sexe);
		panSex.add(getSexe);
		
		centre = new JPanel();
		centre.setOpaque(false);
		centre.setLayout(new BorderLayout());
		centre.setPreferredSize(new Dimension(400, 178));
		centre.add(panImg, BorderLayout.EAST);
		centre.add(panSex, BorderLayout.CENTER);
		centre.add(ouest, BorderLayout.WEST);
		
		spaceWest = new JPanel();
		spaceWest.setPreferredSize(new Dimension(20, 178));
		spaceWest.setOpaque(false);
		
		spaceEast = new JPanel();
		spaceEast.setPreferredSize(new Dimension(20, 178));
		spaceEast.setOpaque(false);
		
		barCode = new JLabel(new ImageIcon(getClass().getResource("BarCode.png")));
		lbId = new JLabel("45637478");
		panId = new JPanel();
		panId.setOpaque(false);
		panId.add(lbId);
		
		panBar = new JPanel();
		panBar.setOpaque(false);
		panBar.setPreferredSize(new Dimension(121, 75));
		panBar.setLayout(new BorderLayout());
		panBar.add(barCode, BorderLayout.NORTH);
		panBar.add(panId, BorderLayout.CENTER);
		
		panAll = new JPanel(){
			protected void paintComponent(Graphics gra){
	             super.paintComponent(gra);
	             try{	                 
	                 image = ImageIO.read(getClass().getResource("Carde.png"));
	             }catch(Exception rx){}
	            gra.drawImage(image,0,0,null);
	            }
		};
		panAll.setPreferredSize(new Dimension(434, 278));
		panAll.setBounds(20, 20, 434, 278);
		panAll.setLayout(new BorderLayout());
		panAll.add(space, BorderLayout.NORTH);
		panAll.add(centre, BorderLayout.CENTER);
		panAll.add(spaceWest, BorderLayout.WEST);
		panAll.add(spaceEast, BorderLayout.EAST);
		panAll.add(panBar, BorderLayout.SOUTH);
		
		btn = new eLib.komponenMakeOver.buttonMakeOver();
		btn.setForeground(new java.awt.Color(0, 0, 0));
		btn.setText("Imprimer");
		btn.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
		btn.addActionListener(new Impression(panAll));
		btn.setBounds(-10, 0, 420, 80);
		
		btn1 = new eLib.komponenMakeOver.buttonMakeOver();
		btn1.setForeground(new java.awt.Color(0, 0, 0));
		btn1.setText("Fermer");
		btn1.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
		btn1.addActionListener(this);
		btn1.setBounds(-10, 0, 420, 80);
		
		sud = new JPanel();
		sud.setOpaque(false);		
		sud.add(btn);
		sud.add(btn1);
		
		main = new JPanel();
		main.setLayout(new BorderLayout());		
		main.add(panAll, BorderLayout.NORTH);
		main.add(sud, BorderLayout.SOUTH);
		
		getInfo();
		
		add(main);
		
		validate();
	}
	
	public void getInfo(){
		try {
			con = new connection();
			stat = con.getStatement();
			req = "SELECT nom, email, sexe, adresse, id_abonne FROM abonne WHERE id_abonne = "+Subscriber.nb;			
			rese = stat.executeQuery(req);
			if(rese.next()){
				getNom.setText(rese.getString("nom"));
				getEmail.setText(rese.getString("email"));
				getSexe.setText(rese.getString("sexe"));
				getAdresse.setText(rese.getString("adresse"));
				lbId.setText(""+rese.getInt("id_abonne"));
			}else{
				this.dispose();
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
			e.printStackTrace();
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == btn1){
			dispose();
			new login(null);
		}		
	}
}
