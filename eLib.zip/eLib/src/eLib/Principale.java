package eLib;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.geom.RoundRectangle2D;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import eLib.komponenMakeOver.buttonMakeOver;



@SuppressWarnings("serial")
public class Principale extends JDialog implements ActionListener{
	JPanel nord, centre, sud, panbout, panall, panTit;
	JLabel im, titre, icon, slog;
	Image img;
	buttonMakeOver can, ok;
	TitledBorder bord;
	
	private int posX = 0;
    private int posY = 0;
    
	public Principale(JFrame lanceur)
	{
		super(lanceur);
		setUndecorated(true);
		setVisible(true);		
		setSize(450, 230);
		setLocationRelativeTo(null);
		setShape(new RoundRectangle2D.Double(1, 1, 450, 230, 15, 15));
        
        icon = new JLabel(new ImageIcon(getClass().getResource("po.png")));
        icon.setToolTipText("Fermer");
		icon.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				dispose();
			}
		});		
		panbout = new JPanel();
		panbout.setOpaque(false);
		panbout.setLayout(new FlowLayout());
		panbout.add(icon);
		
		nord = new JPanel();
		nord.setLayout(new BorderLayout());
		nord.setPreferredSize(new Dimension(450, 30));
		nord.setBackground(Color.decode("#afafaf"));
		nord.add(panbout, BorderLayout.EAST);
		
		titre = new JLabel("<html>Biblioth�que Libre-service <br> eLib</html>");
		titre.setFont(new java.awt.Font("sans-serif", 1, 15));
		
		panTit = new JPanel();
		panTit.setOpaque(false);
		panTit.add(titre);
		
		im = new JLabel(new ImageIcon(getClass().getResource("catalogue.png")));
		
		can = new eLib.komponenMakeOver.buttonMakeOver();
		can.setPreferredSize(new Dimension(250, 40));
		can.setForeground(Color.GRAY);
		can.setText("Biblioth�que");
		can.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
		can.addActionListener(this);
		can.setBounds(-10, 0, 420, 80);
		
		ok = new eLib.komponenMakeOver.buttonMakeOver();
		ok.setPreferredSize(new Dimension(250, 40));
		ok.setForeground(Color.decode("#3193fe"));
		ok.setText("Boite � livre");
		ok.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
		ok.addActionListener(this);
		ok.setBounds(-10, 0, 420, 80);
		
		
		panall = new JPanel();
		panall.setBorder(bord);
		panall.setPreferredSize(new Dimension(260, 170));		
		panall.setOpaque(false);
		panall.add(can);
		panall.add(ok);
		
		centre = new JPanel();
		centre.setLayout(new BorderLayout());
		centre.setBackground(Color.decode("#ececec"));
		centre.setPreferredSize(new Dimension(440, 170));
		centre.add(panTit, BorderLayout.NORTH);
		centre.add(im, BorderLayout.WEST);
		centre.add(panall, BorderLayout.CENTER);
		
		setLayout(new BorderLayout());		
		addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                posX = e.getX();
                posY = e.getY();
            }
        });		
		addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int depX = e.getX() - posX;
                int depY = e.getY() - posY;
                setLocation(getX()+depX, getY()+depY);
            }
        });
		
		slog = new JLabel("<html>Savoir ou loisir, il ne faut pas choisir, mais lire!</html>");
		slog.setFont(new java.awt.Font("sans-serif", 1, 15));
		
		sud = new JPanel();
		sud.setPreferredSize(new Dimension(450, 40));
		sud.add(slog);
		
		add(nord, BorderLayout.NORTH);
		add(centre, BorderLayout.CENTER);
		add(sud, BorderLayout.SOUTH);
		
		validate();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == can){
			dispose();
			new login(null);
		}		
		if(e.getSource() == ok){
			dispose();
			new box("Boite � livre");
		}
	}
}
