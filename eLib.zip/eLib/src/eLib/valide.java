package eLib;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class valide {
	static String mailPattern;
	static Pattern pattern;
	static Matcher matcher;
	
	public static boolean valider(String email){
		boolean status = false;
			mailPattern = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9-])*(\\.[A-Za-z]{2,})$";
			pattern = Pattern.compile(mailPattern);
			matcher = pattern.matcher(email);
			
			if(matcher.matches()){
				status = true;
			}else{
				status = false;
			}
		return status;
	}
}
