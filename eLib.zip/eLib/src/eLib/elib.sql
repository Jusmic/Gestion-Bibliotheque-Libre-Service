-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Lun 13 Avril 2020 à 09:41
-- Version du serveur :  5.0.45-community-nt
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `elib`
--

-- --------------------------------------------------------

--
-- Structure de la table `abonne`
--

CREATE TABLE IF NOT EXISTS `abonne` (
  `id_abonne` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `sexe` varchar(30) NOT NULL,
  `adresse` varchar(50) NOT NULL,
  `typeUser` varchar(50) NOT NULL,
  `dateEnr` varchar(50) NOT NULL,
  `compteur` int(11) NOT NULL,
  PRIMARY KEY  (`id_abonne`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `abonne`
--

INSERT INTO `abonne` (`id_abonne`, `nom`, `email`, `sexe`, `adresse`, `typeUser`, `dateEnr`, `compteur`) VALUES
(94492280, 'Brother John', 'schneiderjohn733@gmail.com', 'Masculin', 'Leurbourgs rue Alexis Moise #24', 'Admin', '13/04/2020', 0);

-- --------------------------------------------------------

--
-- Structure de la table `carte`
--

CREATE TABLE IF NOT EXISTS `carte` (
  `code_PIN` int(11) NOT NULL,
  `id_abonne` int(11) NOT NULL,
  `period` varchar(50) NOT NULL,
  `etat` varchar(50) NOT NULL,
  PRIMARY KEY  (`code_PIN`),
  KEY `fk_1` (`id_abonne`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `carte`
--

INSERT INTO `carte` (`code_PIN`, `id_abonne`, `period`, `etat`) VALUES
(7324, 94492280, '30 jours', 'Active');

-- --------------------------------------------------------

--
-- Structure de la table `emprunt`
--

CREATE TABLE IF NOT EXISTS `emprunt` (
  `Code_emprunt` varchar(255) NOT NULL,
  `code_PIN` int(11) NOT NULL,
  `ISBN` varchar(255) NOT NULL,
  `dateEmprunt` varchar(255) NOT NULL,
  PRIMARY KEY  (`Code_emprunt`),
  KEY `fk_2` (`code_PIN`),
  KEY `fk_3` (`ISBN`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `livre`
--

CREATE TABLE IF NOT EXISTS `livre` (
  `ISBN` varchar(255) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `auteur` varchar(255) NOT NULL,
  `editeur` varchar(255) NOT NULL,
  `dateEdition` varchar(255) NOT NULL,
  `page` varchar(255) NOT NULL,
  `langue` varchar(255) NOT NULL,
  `categorie` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `disponibilite` varchar(255) NOT NULL,
  PRIMARY KEY  (`ISBN`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `livre`
--

INSERT INTO `livre` (`ISBN`, `titre`, `auteur`, `editeur`, `dateEdition`, `page`, `langue`, `categorie`, `description`, `disponibilite`) VALUES
('4007078265896', 'Blanche neige', 'Georges Blaide', 'John Brown', '11/06/2003', '60', 'Francais', 'Jeunesse', 'Fugiat commodi veniam doloremque ducimus temporaLorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat commodi veniam doloremque ducimus tempora. Lorem ipsum dolor sit amet consectetur adipisicing elit.\nFugiat commodi veniam doloremque ducimus temporaLorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat commodi veniam doloremque ducimus tempora. Lorem ipsum dolor sit amet consectetur adipisicing elit.', 'Oui');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `carte`
--
ALTER TABLE `carte`
  ADD CONSTRAINT `fk_1` FOREIGN KEY (`id_abonne`) REFERENCES `abonne` (`id_abonne`);

--
-- Contraintes pour la table `emprunt`
--
ALTER TABLE `emprunt`
  ADD CONSTRAINT `fk_2` FOREIGN KEY (`code_PIN`) REFERENCES `carte` (`code_PIN`),
  ADD CONSTRAINT `fk_3` FOREIGN KEY (`ISBN`) REFERENCES `livre` (`ISBN`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
