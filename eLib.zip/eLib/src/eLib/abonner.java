package eLib;

import java.sql.*;

import javax.swing.JOptionPane;

public class abonner {
int id_abonne, compteur;
String nom, email, sexe, adresse, typeUser, dateEnr;

private static connection con;
private static Statement stat;
private static ResultSet rese;

static String req;
	
	public abonner(int id_abonne, String nom, String email, String sexe, String adresse, String typeUser, String dateEnr, int compteur){
		this.id_abonne = id_abonne;
		this.nom = nom;
		this.email = email;
		this.sexe = sexe;
		this.adresse = adresse;
		this.typeUser = typeUser;
		this.dateEnr = dateEnr;
		this.compteur = compteur;
	}
	
	//Accesseurs...
	public int getId_abonne(){
		return this.id_abonne;
	}
	public String getNom(){
		return this.nom;
	}
	public String getEmail(){
		return this.email;
	}
	public String getSexe(){
		return this.sexe;
	}
	public String getAdresse(){
		return this.adresse;
	}
	public String getTypeUser(){
		return this.typeUser;
	}	
	public String getDateEnr(){
		return this.dateEnr;
	}
	public int getCompteur(){
		return this.compteur;
	}
	
	//Mutateurs...
	public void setId_abonne(int id_abonne){
		this.id_abonne = id_abonne;
	}
	public void setNom(String nom){
		this.nom = nom;
	}
	public void setEmail(String email){
		this.email = email;
	}
	public void setSexe(String sexe){
		this.sexe = sexe;
	}	
	public void setAdresse(String adresse){
		this.adresse = adresse;
	}
	public void setTypeUser(String typeUser){
		this.typeUser = typeUser;
	}	
	public void setDateEnr(String dateEnr){
		this.dateEnr = dateEnr;
	}	
	public void setCompteur(int compteur){
		this.compteur = compteur;
	}
	
	public static void ins_Abonne(int id_abonne, String nom, String email, String sexe, String adresse, String typeUser, String dateEnr, int compteur){
		try {
			con = new connection();
			stat = con.getStatement();
			req = "SELECT * FROM abonne WHERE id_abonne = "+id_abonne;			
			rese = stat.executeQuery(req);
			if(rese.next()){
				JOptionPane.showMessageDialog(null, "Ce code �xiste d�j� dans notre archive.");
			}else{
				req = "INSERT INTO abonne VALUES("+id_abonne+", '"+nom+"', '"+email+"', '"+sexe+"', '"+adresse+"', '"+typeUser+"', '"+dateEnr+"', "+compteur+")";
				stat.executeUpdate(req);
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
			e.printStackTrace();
		}
	}
}
