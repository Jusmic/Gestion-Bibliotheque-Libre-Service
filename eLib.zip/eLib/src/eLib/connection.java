package eLib;
 

import java.sql.*;

import javax.swing.JOptionPane;

public class connection {
	private Connection con;
    private Statement stat;
    private ResultSet rese;
    
    public connection(){
    	try
        {
            Class.forName("com.mysql.jdbc.Driver");
	        con = DriverManager.getConnection("jdbc:mysql://localhost/elib", "root", "");
	        stat=con.createStatement();
        }
        catch(ClassNotFoundException e)
        {
            JOptionPane.showMessageDialog(null,"Chargement impossible :"+e.toString());
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,"Erreur! sql :"+e.toString());
        }   
    }
    
  //accesseurs et mutateurs
    public Connection getConnection()
    {
        return this.con;
    }
    public Statement getStatement()
    {
        return this.stat;
    }
    public ResultSet getResultSet()
    {
        return this.rese;
    }
    public void setConnection(Connection con)
    {
        this.con=con;
    }
    public void setStatement(Statement stat)
    {
        this.stat=stat;
    }
    public void setResultSet(ResultSet rese)
    {
        this.rese=rese;
    }
}
